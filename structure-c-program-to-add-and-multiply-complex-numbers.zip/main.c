#include <stdio.h>

// Define the structure named 'complex' to represent a complex number
struct complex {
    double real;
    double imaginary;
};

// Function to add two complex numbers
struct complex add(struct complex n1, struct complex n2) {
    struct complex temp;
    temp.real = n1.real + n2.real;
    temp.imaginary = n1.imaginary + n2.imaginary;
    return temp;
}

// Function to multiply two complex numbers
struct complex multiply(struct complex n1, struct complex n2) {
    struct complex temp;
    temp.real = (n1.real * n2.real) - (n1.imaginary * n2.imaginary);
    temp.imaginary = (n1.real * n2.imaginary) + (n1.imaginary * n2.real);
    return temp;
}

int main() {
    struct complex num1, num2, sum, product;

    // Input the first complex number
    printf("For first complex number:\n");
    printf("Enter real part: ");
    if (scanf("%lf", &num1.real) != 1) return 1;
    printf("Enter imaginary part: ");
    if (scanf("%lf", &num1.imaginary) != 1) return 1;

    // Input the second complex number
    printf("\nFor second complex number:\n");
    printf("Enter real part: ");
    if (scanf("%lf", &num2.real) != 1) return 1;
    printf("Enter imaginary part: ");
    if (scanf("%lf", &num2.imaginary) != 1) return 1;

    // Perform addition
    sum = add(num1, num2);

    // Perform multiplication
    product = multiply(num1, num2);

    // Display the results
    printf("\nSum = %.2lf + %.2lfi\n", sum.real, sum.imaginary);
    printf("Product = %.2lf + %.2lfi\n", product.real, product.imaginary);

    return 0;
}

