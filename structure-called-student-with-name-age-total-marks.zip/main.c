#include <stdio.h>

// 1. Define the structure for a student
struct Student {
    char name[50];
    int age;
    float total_marks;
};

int main() {
    
    struct Student student1, student2;
    float average_marks;

    // --- Input data for Student 1 ---
    printf("Enter information for student 1:\n");
    printf("Name: ");
    scanf("%s", student1.name); 
    printf("Age: ");
    scanf("%d", &student1.age);
    printf("Total Marks: ");
    scanf("%f", &student1.total_marks);
    printf("\n");

    // --- Input data for Student 2 ---
    printf("Enter information for student 2:\n");
    printf("Name: ");
    scanf("%s", student2.name);
    printf("Age: ");
    scanf("%d", &student2.age);
    printf("Total Marks: ");
    scanf("%f", &student2.total_marks);
    printf("\n");

    // --- Display information for both students ---
    printf("--- Student Information ---\n");
    printf("Student 1:\n");
    printf("  Name: %s\n", student1.name);
    printf("  Age: %d\n", student1.age);
    printf("  Total Marks: %.2f\n", student1.total_marks);

    printf("Student 2:\n");
    printf("  Name: %s\n", student2.name);
    printf("  Age: %d\n", student2.age);
    printf("  Total Marks: %.2f\n", student2.total_marks);
    printf("\n");

    // --- Calculate the average of total marks ---
    average_marks = (student1.total_marks + student2.total_marks) / 2.0;

    printf("Average of total marks for both students: %.2f\n", average_marks);

    return 0;
}
