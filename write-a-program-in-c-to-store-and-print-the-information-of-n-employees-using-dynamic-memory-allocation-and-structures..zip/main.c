#include <stdio.h>
#include <stdlib.h>


struct Employee {
    int id;
    char name[50];
    float salary;
};

int main() {
    int n, i;
  
    struct Employee *employees;

  
    printf("Enter the number of employees (N): ");
    if (scanf("%d", &n) != 1 || n <= 0) {
        printf("Invalid input for N. Exiting program.\n");
        return 1;
    }

  
    employees = (struct Employee *)malloc(n * sizeof(struct Employee));

    if (employees == NULL) {
        printf("Memory allocation failed. Exiting program.\n");
        return 1;
    }

    printf("\nEnter employee details:\n");
    for (i = 0; i < n; i++) {
        printf("\nEmployee %d:\n", i + 1);
        printf("Enter ID: ");
       
        scanf("%d", &(employees + i)->id); 

      
        while (getchar() != '\n'); 

        printf("Enter Name: ");
        
        scanf("%s", (employees + i)->name);

        printf("Enter Salary: ");
        scanf("%f", &(employees + i)->salary);
    }

    // Print the information of all employees
    printf("\n--- Employee Information ---\n");
    for (i = 0; i < n; i++) {
        printf("\nEmployee %d:\n", i + 1);
        printf("ID: %d\n", (employees + i)->id);
        printf("Name: %s\n", (employees + i)->name);
        printf("Salary: %.2f\n", (employees + i)->salary);
    }

    
    free(employees);
    printf("\nMemory freed. Program finished.\n");

    return 0;
}
