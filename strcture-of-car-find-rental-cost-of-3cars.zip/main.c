#include <stdio.h>

#include <string.h>


struct car {

    int id;

    char model[50];

    float rental_rate;

};


int main() {

    struct car cars[3];

    int days;


    printf("Enter details for three cars:\n");

    for (int i = 0; i < 3; i++) {

        printf("Car %d ID: ", i + 1);

        scanf("%d", &cars[i].id);

        printf("Car %d Model: ", i + 1);

        scanf("%s", cars[i].model);

        printf("Car %d Rental Rate (per day): ", i + 1);

        scanf("%f", &cars[i].rental_rate);

    }


    printf("\nEnter the number of rental days: ");

    scanf("%d", &days);


    printf("\n--- Rental Costs ---\n");

    for (int i = 0; i < 3; i++) {

        float total_cost = cars[i].rental_rate * days;

        printf("Car ID: %d, Model: %s\n", cars[i].id, cars[i].model);

        printf("Total Rental Cost for %d days: $%.2f\n", days, total_cost);

        printf("---\n");

    }


    return 0;

}


